from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.views.generic import ListView, DetailView
from django.shortcuts import render
from django.db.models import Q

from book.models import Book, Genre


class HomeView(ListView):
    template_name = 'index.html'
    queryset = Book.objects.all()

def home(request):
    search = request.GET.get('search','')

    if search:
        books = Book.objects.filter(Q(name__icontains=search))
    else:
        books = Book.objects.all()

    genres = Genre.objects.all()

    return render(request, 'index.html', {'books':books, 'genres':genres})

def get_context_data(self, *, object_list=None, **kwargs):
    context = super(HomeView, self).get_context_data()
    print(context)
    return context

def genre(request, pk):
    genres = Genre.objects.all()
    genr = Genre.objects.get(pk=pk)

    if Book.objects.filter(genre_id=genr.id).exists():
        books = Book.objects.filter(genre_id=genr.id)
    else:
        books = Book.objects.all()

    return render(request, 'index.html', {'books':books, 'genres':genres})

class BookDetailView(generic.DetailView):
    model = Book
    # queryset = Book.objects.all()
    template_name = 'detail.html'


class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'


# def search(request):
#     try:
#         if request.method=="POST":
#             article_text = request.POST.get("search_field")
#             if len(article_text)>0:
#                 search_res = Book.objects.filter(name__contains=name)
#             return render(request, "search.html",
#                         {"search_res":search_res,"empty_res":"There is no article"})
#     except:
#         return render(request, "search.html",{"empty_res":"There is no article"})


def contacts(request):
    return render(request, "contact.html")

def account(request):
    return render(request, "account.html")