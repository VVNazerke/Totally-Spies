from django.urls import path

from book import views

urlpatterns = [
    # HomeView.as_view()
    path('', views.home, name='home'),
    path('book/<int:pk>/', views.BookDetailView.as_view(), name='book_detail'),
    # path('search/', views.search, name='search'),
    path('login/', views.HomeView.as_view()),
    path('contacts/', views.contacts, name="contacts"),
    # path('account/', views.account, name="account"),
    path('genres/<int:pk>/', views.genre, name='genre'),
]
